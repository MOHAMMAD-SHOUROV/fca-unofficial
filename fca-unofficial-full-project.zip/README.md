# FCA Unofficial Bot

This is a simple Facebook bot using fca-unofficial and appstate login.